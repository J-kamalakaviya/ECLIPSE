class Main {
    public static void main(String[] args) {

        int age = 16;  

        
        if (!(age >= 18)) {
            System.out.println("Person is NOT eligible to vote");
        } else {
            System.out.println("Person is eligible to vote");
        }
    }
}
