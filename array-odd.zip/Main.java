public class Main {
    public static void main(String[] args) {
        int[] numbers = {10, 15, 20, 23, 30, 41, 50};

        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 != 0) {
                System.out.println(numbers[i]);
            }
        }
    }
}

